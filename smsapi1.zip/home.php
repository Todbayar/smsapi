<section class="services home" style="padding-top:20px; padding-bottom:20px">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="section-title">
					<h2>Заавар</h2>
					<img src="img/separator.png" style="width:250px; height:2px">
					<p>SMS gateway хэрхэн ашиглах тухай заавар</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="icofont-code-alt"></i>
					<h4>General Treatment</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus dictum eros ut imperdiet. </p>	
				</div>
				<!-- End Single Service -->
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="icofont icofont-tooth"></i>
					<h4><a href="service-details.html">Teeth Whitening</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus dictum eros ut imperdiet. </p>	
				</div>
				<!-- End Single Service -->
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="icofont icofont-heart-alt"></i>
					<h4><a href="service-details.html">Heart Surgery</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus dictum eros ut imperdiet. </p>	
				</div>
				<!-- End Single Service -->
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="icofont icofont-listening"></i>
					<h4><a href="service-details.html">Ear Treatment</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus dictum eros ut imperdiet. </p>	
				</div>
				<!-- End Single Service -->
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="icofont icofont-eye-alt"></i>
					<h4><a href="service-details.html">Vision Problems</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus dictum eros ut imperdiet. </p>	
				</div>
				<!-- End Single Service -->
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="icofont icofont-blood"></i>
					<h4><a href="service-details.html">Blood Transfusion</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus dictum eros ut imperdiet. </p>	
				</div>
				<!-- End Single Service -->
			</div>
		</div>
	</div>
</section>