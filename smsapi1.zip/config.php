<?php
define("AUTH_USER","99213557");
define("AUTH_PASS","hThlH8d09tJ,");
define("SERVER_ADDRESS","tcp://0.tcp.ap.ngrok.io:10792");
?>