<?php
define("TITLE","SMS баталгаажуулалт, мэдэгдэл");
?>